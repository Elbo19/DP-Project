/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reception_demo;

import java.util.ArrayList;

/**
 *
 * @author Lulit
 */
public class Decorator {
    
     
   public Decorator(){
      
   }

    /**
     *
     * @param message
     * @return
     */
   ArrayList<String> decorated_message;
   boolean add;
    public ArrayList<String> decorate(ArrayList<String> message, ArrayList<String> newarr){
        newarr = new ArrayList<>();
      
       for (String message1 : message) {
      
       String s = message1.toUpperCase();
       newarr.add(s);
  
       }
    
      return newarr;
       
            
  
   }
    
}
