/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reception_demo;

/**
 *
 * @author Lulit
 */
public class Emp_Factory {

    /**
     *
     * @param empType
     * @return
     */
    public Reception Get_Emp(String empType){
      if(empType == null){
         return null;
      }		
      if(empType.equalsIgnoreCase("VIP")){
         return new VIP_register();
         
      } else if(empType.equalsIgnoreCase("Regular")){
         return new Regular_Register();
         
      } 
      else{
      return null;
      }
   }

   

    
}
