/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reception_demo;

import java.util.ArrayList;

/**
 *
 * @author Lulit
 */
public class Guest_Repo implements Container {
  private ArrayList<String> names;
    //Regular_Register reg = new Regular_Register();
    public Guest_Repo(ArrayList<String> name){
    this.names =name;
    
    }
     @Override
     
   public Iterator getIterator() {
      return new Guest_Iterator(names);
}
}