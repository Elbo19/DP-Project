/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package question2;

/**
 *
 * +03
 * 
 * @author hp
 */
public class CV implements View {

    @Override
    public void display() {
        System.out.println("CV should display");
        //System.out.println(jproducts);
    }

    
    
    
}
