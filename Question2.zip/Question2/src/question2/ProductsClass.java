/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package question2;

import java.util.ArrayList;

/**
 *
 * @author hp
 */
abstract public class ProductsClass {
    View v;
    
    public ProductsClass(View v){
        this.v = v;
    }
    

    
    abstract public void getDescription();
    
    
}
